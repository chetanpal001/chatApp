package com.ofbusiness.chatapp.repository;

import com.ofbusiness.chatapp.entity.UserChat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<UserChat, UUID> {
    void deleteByMessageId(UUID messageId);

    @Query(value = "select * from public.user_chat c where c.user_id=:id", nativeQuery = true)
    List<UserChat> getChatLogsForUser(String id);

    @Query(value = "delete from public.user_chat c where c.user_id=:id", nativeQuery = true)
    void deleteByUserId(String id);
}
