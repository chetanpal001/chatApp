//package com.ofbusiness.chatapp.entity;
//
//import jakarta.persistence.*;
//import lombok.*;
//import lombok.experimental.FieldDefaults;
//import org.hibernate.annotations.GenericGenerator;
//import org.springframework.data.annotation.CreatedDate;
//import org.springframework.data.annotation.LastModifiedDate;
//
//import java.util.Date;
//import java.util.UUID;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Builder
//@Entity
//@Table(name = "Message")
//@FieldDefaults(level = AccessLevel.PRIVATE)
//public class Message {
//    @Id
//    @GeneratedValue(generator = "UUID")
//    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
//    @Column(name = "id", updatable = false, nullable = false)
//    UUID id;
//
//    @Column(name = "message", updatable = false, nullable = false)
//    private String message;
//
//    @ManyToOne
//    @JoinColumn(name = "user_id")
//    private User user;
//    @Column(name = "created_date_time")
//    @CreatedDate
//    private Date createdDateTime;
//
//    @Column(name = "updated_date_time")
//    @LastModifiedDate
//    private Date updatedDateTime;
//}
