package com.ofbusiness.chatapp.service;

import com.ofbusiness.chatapp.entity.UserChat;
import com.ofbusiness.chatapp.exception.ChatCreationException;
import com.ofbusiness.chatapp.model.UserDto;
import com.ofbusiness.chatapp.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
//import static com.ofbusiness.chatapp.mapper.UserMapper.INSTANCE;

@Service
@Slf4j
public class ChatLogService {

    @Autowired
    private UserRepository userRepository;
    public UUID createChatlog(UserDto userDto){
        //var userEntity = INSTANCE.mapUserEntity(userDto);
        try {
        var userEntity = UserChat.builder()
                .message(userDto.getMessage())
                .isSent(userDto.getIsSent())
                .messageId(UUID.randomUUID())
                .userId(userDto.getUserId())
                .build();
            var userResponse = userRepository.save(userEntity);
            return userResponse.getMessageId();
        }catch (Exception ex){
            log.error("Error while creating the chats");
            throw new ChatCreationException(ex.getMessage());
        }
    }

    public List<UserChat> getChatLogs(String userId, Integer limit, UUID start){
        try {
            var chats = userRepository.getChatLogsForUser(userId);
            return chats;
        }catch (Exception ex){
            log.error("Error while getting the chats");
            throw new RuntimeException(ex.getMessage());
        }
    }

    public void deleteChatLogs(){
        try {
            userRepository.deleteAll();
        }catch (Exception ex){
            log.error("Error while deleting the chat logs");
            throw new RuntimeException(ex.getMessage());
        }
        //userRepository.deleteByUserId(userId);
    }

    @Transactional
    public void deleteChatMessage(UUID messageId){
        try {
            userRepository.deleteByMessageId(messageId);
        }catch (Exception ex){
            log.error("Error while deleting the message");
            throw new RuntimeException(ex.getMessage());
        }
    }
}
