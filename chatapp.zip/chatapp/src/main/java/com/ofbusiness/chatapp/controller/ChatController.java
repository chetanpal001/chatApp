package com.ofbusiness.chatapp.controller;

import com.ofbusiness.chatapp.entity.UserChat;
import com.ofbusiness.chatapp.model.UserDto;
import com.ofbusiness.chatapp.service.ChatLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/chatlogs/user")
public class ChatController {
    @Autowired
    ChatLogService chatLogService;

    @PostMapping()
    public UUID createChatlogs(@RequestBody UserDto userDto){
        return chatLogService.createChatlog(userDto);
    }

    @GetMapping(value = "/{id}")
    public List<UserChat> getChatlogs(@PathVariable String id,
                                      @RequestParam(defaultValue = "10") Integer limit,
                                      @RequestParam(required = false) UUID start){
        return chatLogService.getChatLogs(id,limit,start);
    }

    @DeleteMapping()
    public String deleteChatlogs(){
        chatLogService.deleteChatLogs();
        return "Chat Log deleted Successfully";
    }

    @DeleteMapping(value = "/{msgID}")
    public String deleteMessage(@PathVariable UUID msgID){
        chatLogService.deleteChatMessage(msgID);
        return "Chat message deleted successfully";
    }

}
