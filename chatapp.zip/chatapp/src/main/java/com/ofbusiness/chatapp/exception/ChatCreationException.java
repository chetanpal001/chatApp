package com.ofbusiness.chatapp.exception;

public class ChatCreationException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    public ChatCreationException(String errorMessage, Throwable err) {
        super(errorMessage, err);
    }

    public ChatCreationException(String message) {
        super(message);
    }
}
