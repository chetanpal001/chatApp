package com.ofbusiness.chatapp.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import java.util.Date;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "user_chat")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserChat {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "id", updatable = false, nullable = false)
    UUID id;

//    @Column(name = "messageId", updatable = false, nullable = false)
//    private Message message;

//    @OneToMany(cascade = CascadeType.ALL)
//    private List<Message> message;

    @Column(name = "userId")
    String userId;
    @Column(name = "messageId")
    UUID messageId;

    @Column(name = "message")
    String message;

    @Column(name = "isSent")
    Boolean isSent;

    @Column(name = "created_date_time")
    @CreatedDate
    Date createdDateTime;

    @Column(name = "updated_date_time")
    @LastModifiedDate
    Date updatedDateTime;
}
