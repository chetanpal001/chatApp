//package com.ofbusiness.chatapp.mapper;
//
//import com.ofbusiness.chatapp.entity.User;
//import com.ofbusiness.chatapp.model.UserDto;
//import org.mapstruct.Mapper;
//import org.mapstruct.Mapping;
//import org.mapstruct.Named;
//import org.mapstruct.factory.Mappers;
//
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.Random;
//import java.util.UUID;
//
//@Mapper(componentModel = "spring")
//public interface UserMapper {
//
//    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);
//
//    @Mapping(source = "userDto", target = "messageId", qualifiedByName = "setMessageId")
//    User mapUserEntity(UserDto userDto);
//
//    @Named("setMessageId")
//    default UUID setChatMessageId(UserDto userDto) {
//        return UUID.randomUUID();
//    }
//}
