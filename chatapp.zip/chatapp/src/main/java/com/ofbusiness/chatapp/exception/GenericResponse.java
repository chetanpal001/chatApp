package com.ofbusiness.chatapp.exception;

import lombok.Data;

@Data
public class GenericResponse {

    private String errorMessage;

    public GenericResponse(String message) {
        this.errorMessage = message;
    }
}